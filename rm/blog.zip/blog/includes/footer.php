
      </div><!-- /.row -->

    </div><!-- /.container -->

    <footer class="blog-footer">
      <p><a href="#">IDiscuss</a>,Copyright &copy;<br>
    +251-9-00-00-00-00</p> 
      <p>
        <a href="#">Back to top</a>
      </p>
    </footer>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.js"></script>
   
  </body>

</html>