/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 5.7.19 : Database - blog
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`blog` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `blog`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `admin` */

insert  into `admin`(`username`,`password`) values ('admin',''),('admin','12345');

/*Table structure for table `categories` */

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `categories` */

insert  into `categories`(`id`,`text`) values (1,'java'),(2,'php\r\n'),(3,'programmin'),(4,'c#');

/*Table structure for table `comments` */

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `comment` text NOT NULL,
  `post` int(11) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `validated` int(1) NOT NULL DEFAULT '0',
  `v_count` int(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=137 DEFAULT CHARSET=latin1;

/*Data for the table `comments` */

insert  into `comments`(`id`,`name`,`comment`,`post`,`status`,`validated`,`v_count`) values (103,'kirub','yolo\r\n',1,1,1,5),(98,'gdhj','done',1,1,1,2),(97,'fanu','heyyy',2,1,1,0),(96,'yasir ','thanks',1,1,1,5),(110,'kirub','oubfrubdfij',4,0,0,0),(111,'cherub','hbkdbckbd c ckdbdkc ',2,0,1,1),(112,'tester','tested',7,1,1,9),(113,'tester','again tested',8,0,1,0),(114,'GVFCD','vtcdxsdfrgt',8,0,0,0),(115,'GVFCD','works',2,0,1,0),(116,'mee','yooo it works\r\n',1,0,1,2),(117,'kira','session test',1,0,1,1),(118,'kira','and again',1,0,1,1),(119,'kira','tester',4,0,0,0),(120,'','logged out',4,0,0,0),(121,'kira','yayyyy',12,0,1,0),(122,'kira','',12,0,1,0),(123,'kira','yup\r\n',11,0,1,0),(124,'kira','testtttt\r\n',9,0,1,1),(125,'kira','tcdxs',7,0,1,1),(126,'kira','final',1,0,1,1),(127,'kira','bjhknfcdx',7,0,0,NULL),(128,'tester','halooo',7,0,0,NULL),(129,'tester','this is it',13,0,1,1),(130,'kira','works',37,0,0,NULL),(131,'@suraK','hhhhhhh',40,0,1,2),(132,'@matiman','jjj',41,0,1,1),(133,'miko','fshshs',43,0,1,2),(134,'kira','hhh',46,0,1,1),(135,'kira','hfkykykvutk6i',50,0,1,2),(136,'@moe','hhhhhk',46,0,0,NULL);

/*Table structure for table `files` */

DROP TABLE IF EXISTS `files`;

CREATE TABLE `files` (
  `filename` varchar(100) NOT NULL,
  `path` varchar(100) NOT NULL,
  `post_id` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `files` */

insert  into `files`(`filename`,`path`,`post_id`) values ('12 Mobile Photography Tips Every Photographer Should Know.pdf','./upload/12 Mobile Photography Tips Every Photographer Should Know.pdf',0),('31E6C56F-7AC8-48FC-8937-DF8FC6B2675C_w1023_r1_s.jpg','./upload/31E6C56F-7AC8-48FC-8937-DF8FC6B2675C_w1023_r1_s.jpg',0);

/*Table structure for table `hilreg` */

DROP TABLE IF EXISTS `hilreg`;

CREATE TABLE `hilreg` (
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `usname` varchar(30) NOT NULL,
  `sclid` varchar(20) NOT NULL,
  `pwd` varchar(100) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`sclid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `hilreg` */

insert  into `hilreg`(`fname`,`lname`,`usname`,`sclid`,`pwd`,`status`) values ('kirubel','yilma','cherub','rd0405','$2y$10$25D0cJEVI2lKCId215/PBurKPbJ1F/pdPYJ0OASfjpeU8p1qR.A6a',1),('baharu','getachew','baharu','bfkjd','$2y$10$YFxqv4uLvJpPX5G8rtoUROus/cNMG2kKTg/R3Wxzz5iqJ5Zue9Lla',1),('kirubel','yilma','kira','12345','$2y$10$M3Sk/JX9fs4hlh6GL/Bspe.Cjp6rt.QBzO5M.JvxQcH8HJfyltq5C',1),('baharu','getachew','bah','bah12','$2y$10$G.HqBAVZUWvfVgy6vbj66ekJ4E7b/xNoyCd3OnryjnSh6WvlUd0/q',0),('kirubel','yilma','tester','tester','$2y$10$rc8NCYEoJ2u2K7jspvZZgOVA6BQ1/.FOlbhhZrHPaTenmNEzUja7i',0),('surafel','kebede','@suraK','2323ss','$2y$10$rkoepJZzcAUvdc9fNVNbt.BJu1hTBOTXUMh//vr6DcaSNrHEbPZpi',1),('Matiyas','Taye','@matiman','mu2590','$2y$10$Tdh62tIyiZccwzM/vxYWCuofqAbsvIFlFqgcu52qKgpfS5Zrd7e6S',1),('miki','kig','miko','kw2660','$2y$10$igsaKjEqXr3mrgrEvOKI2uWIVxZf0.6VjJVow/KVrpZ75KBCx1bQy',1),('ABREHAM','HAILU','@abh','ui9090','$2y$10$OnrH4WC94ZaPG9byP0Gcte1VPdFljNZkRzNojDzwjHjTyMMsfKhRW',1),('mewal','tester','mewtest','mewtest','$2y$10$vtnONwTYZwLHTh3KX3o0dOBwoRcsv44HEdi0kdfYL92wnQJj6EB92',1),('Ted','Girma','ted_girma','ar8906','$2y$10$bvWyvuaGzMcsGirnh2Ha3uBfFgne8ITW1c6RAo/C1SqZ.ZVi9x8zq',1),('Mohammed','Abdella','@moe','HT8472','$2y$10$wzr.L5M9WLVi9xThZ8bw6e6M8ux1n6M6dTsokYhrSNpQwCSFQDYCS',1),('mewale','G/mariam','mewale','kh1102','$2y$10$wkyQHicgvXLmNd8Sh1UUiu6C.YnxfMA7ZeB/PFhFPdms.br8/W9Zm',1);

/*Table structure for table `posts` */

DROP TABLE IF EXISTS `posts`;

CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `category` varchar(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `body` text NOT NULL,
  `author` varchar(100) NOT NULL,
  `keywords` varchar(200) NOT NULL,
  `priority` int(100) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

/*Data for the table `posts` */

insert  into `posts`(`id`,`title`,`category`,`date`,`body`,`author`,`keywords`,`priority`,`filename`,`path`) values (53,'j',' 2','August, 13, 2019','hj','@moe','ygu',NULL,'','./upload/'),(51,'divorce',' 1','August, 10, 2019','fghjkjhv','kira','family',NULL,'','./upload/'),(52,'even handel',' 4','August, 13, 2019','gggg','@moe','mame',NULL,'ask.JPG','./upload/ask.JPG'),(48,'',' 1','August, 9, 2019','n','kira','j',NULL,'','./upload/'),(49,'999',' 1','August, 9, 2019','888','kira','788',NULL,'index.php','./upload/index.php'),(50,'EXPECTED RESULTS IN TESTING',' 4','August, 10, 2019','Expected result\r\nDisplay message â€œplease fill out this fieldâ€.\r\nDisplay message â€œincorrect inputâ€.\r\nContinue and post the question.\r\nContinue and post the file question.\r\nDisplay a notification â€œno file chosen. You want to continue?â€\r\nDisplay message â€œchoose course title from the listed categoryâ€.\r\nContinue and post question.\r\nContinue and post the question.\r\n','ted_girma','testing',2,'FB_IMG_1518848177374.jpg','./upload/FB_IMG_1518848177374.jpg'),(46,'F',' 1','August, 1, 2019','nnn','kira','test',1,'','./upload/'),(45,'sssss',' 2','June, 27, 2019','================================================================================================\r\nCracked by CrackingPatching.com\r\nour New Website Releaseload.com\r\n================================================================================================\r\nHow to Install\r\n1. Intall idm by running idman628build9.exe\r\n2. Run 32bit Patch build 9.exe from Patch 2 folder if you\'re using 32bit operating system\r\nor \r\n   Run 64bit Patch build 9.exe from Patch 2 folder if you\'re using 64bit operating system\r\n3. Done. Enjoy simplest IDM installation ever\r\n4. To uninstall this Patch just go, find and run IDM Patch Uninstaller.exe and follow instructions\r\n\r\nOfficial Websites\r\nhttpcrackingpatching.com\r\nhttpreleaseload.com\r\nFacebook\r\nhttpswww.facebook.comcrackingpatchingcom-498498237016242\r\nTwitter\r\nhttpstwitter.comcrackpatching\r\nGoogle+\r\nhttpsplus.google.com110930260116133303958','miko','test',NULL,'','./upload/'),(44,'sssss',' 2','June, 27, 2019','================================================================================================\r\nCracked by CrackingPatching.com\r\nour New Website Releaseload.com\r\n================================================================================================\r\nHow to Install\r\n1. Intall idm by running idman628build9.exe\r\n2. Run 32bit Patch build 9.exe from Patch 2 folder if you\'re using 32bit operating system\r\nor \r\n   Run 64bit Patch build 9.exe from Patch 2 folder if you\'re using 64bit operating system\r\n3. Done. Enjoy simplest IDM installation ever\r\n4. To uninstall this Patch just go, find and run IDM Patch Uninstaller.exe and follow instructions\r\n\r\nOfficial Websites\r\nhttpcrackingpatching.com\r\nhttpreleaseload.com\r\nFacebook\r\nhttpswww.facebook.comcrackingpatchingcom-498498237016242\r\nTwitter\r\nhttpstwitter.comcrackpatching\r\nGoogle+\r\nhttpsplus.google.com110930260116133303958','miko','test',NULL,'','./upload/'),(47,'hhhh',' 1','August, 9, 2019','hhh','kira','12345',NULL,'','./upload/'),(43,'á•áˆ®áŒáˆ«áˆšáŠ•áŒ',' 2','June, 27, 2019','gargarg','kira','test',1,'calculus.docx','./upload/calculus.docx');

/*Table structure for table `priority` */

DROP TABLE IF EXISTS `priority`;

CREATE TABLE `priority` (
  `post_id` int(11) NOT NULL,
  `priored_by` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `priority` */

insert  into `priority`(`post_id`,`priored_by`) values (8,12345),(12,12345),(2,12345),(7,12345),(11,12345),(9,12345),(13,12345),(41,12345),(46,12345),(50,12345);

/*Table structure for table `test` */

DROP TABLE IF EXISTS `test`;

CREATE TABLE `test` (
  `id` varchar(100) NOT NULL,
  `grade` varchar(200) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `test` */

insert  into `test`(`id`,`grade`,`name`,`type`) values ('this','is','line','1'),('this','is','line','2'),('this','is','line','3'),('this','is','line','4'),('this','is','line','5');

/*Table structure for table `validate` */

DROP TABLE IF EXISTS `validate`;

CREATE TABLE `validate` (
  `validated` int(1) NOT NULL DEFAULT '0',
  `validated_by` varchar(255) NOT NULL,
  `comment_id` int(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `validate` */

insert  into `validate`(`validated`,`validated_by`,`comment_id`) values (0,'113',12345),(0,'113',12345);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
