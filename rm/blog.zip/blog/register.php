
<html>
<head><title>IDiscuss</title></head>
<link href="/forum-tutorial/styles/main.css" type="text/css" rel="stylesheet" />
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/blog.css" rel="stylesheet">

<body>
	<div class="pane">
		<div class="header"><h1>IDiscuss Discusssion Forum </a></h1></div>
		<P style="margin-left: 850px">Already have an Account?<a style="margin-left: 65px" href="index.php" class=" btn btn-primary">Login now </a></P>
	<div class="loginPage">
			<div class="form" padding: 45px; >
				<img src="img/login.png" class="avater" width="50px">
				<form class="registerForm" action="registration.php" method="POST">
					<input style="color: black"; type="text" placeholder="First Name" name="fname" required /> <br>
					<input style="color: black"; type="text" placeholder="Last Name" name="lname"  required/><br>
					<input style="color: black"; type="text" placeholder="User Name" name="usname" /><br>
					<input style="color: black"; type="text" placeholder="School ID" name="sclid" /><br>
					<input style="color: black"; type="password" placeholder="Password" name="pwd" /><br>
					<input style="color: black"; type="password" placeholder="Confirm Password" name="re-pwd"><br>
					<br>
					<button style="color: black"; type="submit" value="Signup" name="signup"> signup</button>
				</form>

				


			</div>

		</div>
		
	
</body>
</html>
