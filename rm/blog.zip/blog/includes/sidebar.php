 <div class="col-sm-3 col-sm-offset-1 blog-sidebar" style="margin-top: 150px;">

          <div class="sidebar-module">
            <h4>Search</h4>
            <hr>
            <form method="POST" action="results.php" class="form-inline">
              <div class="form-group">
                <input type="text" name="Search" class="form-control"  placeholder="search..">
                <button type="submit" name="search" class="btn btn-primary">Search</button>
                
              </div>
              
            </form>
          </div>

          <div class="sidebar-module sidebar-module-inset">
            <h4>About</h4>
            <hr>
            <p>Idiscuss is committed to excellence and continuous improvement. It is being recognized as an innovative, dynamic, and exciting community in which to learn, teach and work. Idiscuss is known for industrious educational quality. To achieve its vision and mission, Idiscuss has created core value oriented organizational structure.</p>
          </div>

          
          <div class="sidebar-module">
            <h4>Find us on</h4>
            <hr>
            <ol class="list-unstyled">
              <li><a href="#">GitHub</a></li>
              <li><a href="#">Twitter</a></li>
              <li><a href="#">Facebook</a></li>
            </ol>
          </div>
        </div><!-- /.blog-sidebar -->